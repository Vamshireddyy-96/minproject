package com.yash.bookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreTask4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
