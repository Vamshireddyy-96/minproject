package com.yash.bookstore.entity;

public enum Role {

	USER, //default
	ADMIN, //admin ,CRUD ops
	MANAGER; //internal ops
}
